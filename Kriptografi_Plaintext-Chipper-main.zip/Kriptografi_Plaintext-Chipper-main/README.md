# Tugas Kriptografi Playfair

## Nama : Yehezkiel Juandro Metta
## NIM  : 312210376
## Kelas: Ti.22.A5

# Hasil Output

![image](https://github.com/user-attachments/assets/f6fa7cdd-c29b-49e5-be00-5da0b6edd671)
